/**
 * @file indexation.h
 * @author Clement Truillet (clement.truillet@univ-tlse3.fr)
 * @brief
 * @version 0.1
 * @date 21/03/2020
 *
 * @copyright Copyright (c) 2020
 *
 */
 #define __INDEXATION__


int indexationTexte (char * argument);