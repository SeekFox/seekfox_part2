# Impeesa

## Recherche    
+ Texte   
  + Recherche Texte *[Fini]*   
+ MotClef   
  + Recherche Mot Clef *[Fini]*   
+ Audio   
  + Recherche Audio *[DONNEES EN DUR]*   
    Resultat d'une recherche audio *jingle_fi.bin*  
+ Image   
  + Recherche Image *[DONNEES EN DUR]*     
    Resultat d'une recherche image NB *51.bmp*

## Indexation  
+ Texte   
  + Indexation Texte *[Fini]*  
+ Audio   
  + Indexation Audio *[En Cours]*   
+ Image   
  + Indexation Image *[A Faire]*   
